# DBT LAB AI Call Assistant — Android APK Build

এই ZIP-টি GitHub repository-তে সরাসরি আপলোড করার মতো করে সাজানো হয়েছে।

## Android ফোন থেকেই APK Build

1. GitHub-এ একটি নতুন repository তৈরি করুন (যেমন `dbt-lab-ai-call-assistant`)।
2. এই ZIP Extract করে এর ভেতরের সব ফাইল ও ফোল্ডার repository-র root-এ আপলোড করুন।
   - খেয়াল রাখবেন `.github/workflows/build-apk.yml`-ও root-এ থাকতে হবে।
   - `app/`, `build.gradle.kts`, `settings.gradle.kts` একই root-এ থাকবে।
3. সব ফাইল Commit করুন।
4. GitHub repository-তে **Actions** ট্যাব খুলুন।
5. **Build DBT LAB AI Call Assistant APK** workflow নির্বাচন করুন।
6. **Run workflow** চাপুন।
7. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে
   `dbt-lab-ai-call-assistant-debug-apk` ডাউনলোড করুন।
8. ZIP extract করে `app-debug.apk` Android ফোনে ইনস্টল করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই ZIP-এ থাকা সোর্স কোড এখানে Android SDK দিয়ে compile করে যাচাই করা হয়নি।
  GitHub Actions build-ই প্রথম প্রকৃত compile/test হবে।
- APK ইনস্টল হলেও Default Phone App role ও runtime permissions দিতে হবে।
- SIM কল স্বয়ংক্রিয়ভাবে Answer করার কোড থাকলেও Android/OEM/ডিভাইসের আচরণে পরীক্ষা জরুরি।
- Android Public API দিয়ে সাধারণ SIM call-এর অপর প্রান্তে Gemini/TTS অডিও পাঠানো সমর্থিত নয়।
  তাই এই APK-কে AI নিজে SIM কলারের সঙ্গে কথা বলতে পারবে বলে ধরে নেবেন না।
- কল রেকর্ডিংয়ের ক্ষেত্রে আইন, অপর পক্ষকে জানানো এবং সম্মতি মেনে চলুন।
