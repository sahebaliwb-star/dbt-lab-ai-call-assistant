package com.dbtlab.callassistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dbtlab.callassistant.data.AutoAnswerPreferencesStore
import com.dbtlab.callassistant.data.CallHistoryRepository
import com.dbtlab.callassistant.data.SimPreferencesStore
import com.dbtlab.callassistant.permissions.AndroidPermissionItem
import com.dbtlab.callassistant.permissions.PermissionManager
import com.dbtlab.callassistant.telecom.AiCallAudioCapabilityReport
import com.dbtlab.callassistant.telecom.AutoAnswerDelay
import com.dbtlab.callassistant.telecom.AutoAnswerGuard
import com.dbtlab.callassistant.telecom.AutoAnswerRuntimeState
import com.dbtlab.callassistant.telecom.AutoAnswerSettings
import com.dbtlab.callassistant.telecom.AutoAnswerTestCheck
import com.dbtlab.callassistant.telecom.DbtInCallService
import com.dbtlab.callassistant.telecom.DialerRoleHelper
import com.dbtlab.callassistant.telecom.DualSimCallMetrics
import com.dbtlab.callassistant.telecom.DualSimInventoryResult
import com.dbtlab.callassistant.telecom.PreferredSimOption
import com.dbtlab.callassistant.telecom.PublicApiCapabilities
import com.dbtlab.callassistant.telecom.SimSlotInfo
import com.dbtlab.callassistant.telecom.SimSubscriptionDetector
import androidx.lifecycle.lifecycleScope
import com.dbtlab.callassistant.ui.DbtColors
import com.dbtlab.callassistant.ui.DbtLabTheme
import com.dbtlab.callassistant.ui.IncomingCallActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var isDefaultDialer by mutableStateOf(false)
    private var inCallServiceRegistered by mutableStateOf(false)
    private var permissionItems by mutableStateOf<List<AndroidPermissionItem>>(emptyList())
    private var simInventory by mutableStateOf(
        DualSimInventoryResult(
            sim1 = SimSlotInfo(1, null, "লোড হচ্ছে...", "Checking", "Unknown", false, false),
            sim2 = SimSlotInfo(2, null, "লোড হচ্ছে...", "Checking", "Unknown", false, false),
            permissionGranted = false,
            summaryNote = "SIM তথ্য লোড হচ্ছে..."
        )
    )
    private var preferredSim by mutableStateOf(PreferredSimOption.ASK_EVERY_TIME)
    private var autoAnswerSettings by mutableStateOf(AutoAnswerSettings())
    private var aiAudioCapability by mutableStateOf(
        AiCallAudioCapabilityReport(
            canInjectAiVoiceIntoSimCall = PublicApiCapabilities.DIRECT_PSTN_UPLINK_AI_INJECTION,
            statusTitleBn = "AI Call Audio Integration: Unsupported (Android Public API)",
            detailBn = "সাধারণ SIM কলের অডিওতে সরাসরি AI Voice পাঠানো Android Public API দ্বারা অসম্ভব।"
        )
    )
    private var autoAnswerTestResults by mutableStateOf<List<AutoAnswerTestCheck>>(emptyList())
    private var simulatedAutoAnswerJob: Job? = null
    private var simTestCountingDown by mutableStateOf(false)
    private var simTestRemainingSec by mutableStateOf(0)
    private var simTestStatusBn by mutableStateOf("")
    private var callHistoryResult by mutableStateOf(
        CallHistoryRepository.CallLogResult(emptyList(), false, "লোড হচ্ছে...")
    )

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshSystemState()
    }

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshSystemState()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshSystemState()

        setContent {
            DbtLabTheme {
                val activeCall by DbtInCallService.callUiState.collectAsState()
                val inCallBound by DbtInCallService.isServiceBound.collectAsState()
                val metrics = CallHistoryRepository.computeDualSimMetrics(
                    history = callHistoryResult,
                    simInventory = simInventory,
                    activeCall = activeCall
                )

                NativeDashboardScreen(
                    isDefaultDialer = isDefaultDialer,
                    inCallServiceRegistered = inCallServiceRegistered,
                    inCallServiceBound = inCallBound,
                    simInventory = simInventory,
                    preferredSim = preferredSim,
                    autoAnswerSettings = autoAnswerSettings,
                    autoAnswerRuntime = activeCall.autoAnswerState,
                    simTestCountingDown = simTestCountingDown,
                    simTestRemainingSec = simTestRemainingSec,
                    simTestStatusBn = simTestStatusBn,
                    aiAudioCapability = aiAudioCapability,
                    autoAnswerTestResults = autoAnswerTestResults,
                    metrics = metrics,
                    permissionItems = permissionItems,
                    callHistoryResult = callHistoryResult,
                    hasActiveCall = activeCall.hasActiveCall,
                    activeCallSummary = "${activeCall.callState.labelBn} · ${activeCall.callerNumber} (${activeCall.simInfo?.statusNote ?: "SIM"})",
                    onSelectPreferredSim = { option ->
                        SimPreferencesStore.setPreferredSim(this, option)
                        preferredSim = option
                    },
                    onToggleAutoAnswer = { enabled ->
                        AutoAnswerPreferencesStore.setEnabled(this, enabled)
                        autoAnswerSettings = AutoAnswerPreferencesStore.load(this)
                    },
                    onSelectAutoAnswerDelay = { delay ->
                        AutoAnswerPreferencesStore.setDelay(this, delay)
                        autoAnswerSettings = AutoAnswerPreferencesStore.load(this)
                    },
                    onToggleAutoAnswerJioOnly = { jioOnly ->
                        AutoAnswerPreferencesStore.setJioOnly(this, jioOnly)
                        autoAnswerSettings = AutoAnswerPreferencesStore.load(this)
                    },
                    onStopAutoAnswerNow = {
                        simulatedAutoAnswerJob?.cancel()
                        simulatedAutoAnswerJob = null
                        if (simTestCountingDown) {
                            simTestCountingDown = false
                            simTestRemainingSec = 0
                            simTestStatusBn = "Stop Auto Answer সফল: ৫ সেকেন্ড কাউন্টডাউন বাতিল হয়েছে।"
                        }
                        DbtInCallService.cancelAutoAnswer(cancelledByUser = true)
                        AutoAnswerPreferencesStore.setEnabled(this, false)
                        autoAnswerSettings = AutoAnswerPreferencesStore.load(this)
                    },
                    onSimulateFiveSecondAutoAnswer = {
                        simulatedAutoAnswerJob?.cancel()
                        if (!autoAnswerSettings.enabled) {
                            simTestCountingDown = false
                            simTestStatusBn = "Auto Answer OFF আছে — তাই কল অটোমেটিক Answer হয়নি।"
                        } else {
                            simulatedAutoAnswerJob = lifecycleScope.launch {
                                val secTotal = autoAnswerSettings.delay.seconds
                                simTestCountingDown = true
                                for (sec in secTotal downTo 1) {
                                    simTestRemainingSec = sec
                                    simTestStatusBn = "টেস্ট Jio SIM কল: $sec সেকেন্ড পর Auto Answer হবে..."
                                    delay(1000L)
                                }
                                simTestCountingDown = false
                                simTestRemainingSec = 0
                                simTestStatusBn = "টেস্ট সফল: ${secTotal}s Delay পর অনুমোদিতভাবে কল Answer স্টেটে পৌঁছেছে (AI Audio ইনজেক্ট ভান করা হয়নি)।"
                            }
                        }
                    },
                    onRunAutoAnswerTests = {
                        lifecycleScope.launch {
                            autoAnswerTestResults = AutoAnswerGuard.runSelfVerificationTests(
                                context = this@MainActivity,
                                currentSettings = autoAnswerSettings
                            )
                        }
                    },
                    onRequestDefaultDialer = {
                        val intent = DialerRoleHelper.createRequestDefaultDialerIntent(this)
                        if (intent != null) {
                            roleLauncher.launch(intent)
                        }
                    },
                    onRequestPermissions = {
                        permissionsLauncher.launch(PermissionManager.requiredRuntimePermissions())
                    },
                    onOpenActiveCallScreen = {
                        startActivity(Intent(this, IncomingCallActivity::class.java))
                    },
                    onRefreshAll = {
                        refreshSystemState()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshSystemState()
    }

    private fun refreshSystemState() {
        isDefaultDialer = DialerRoleHelper.isDefaultDialer(this)
        inCallServiceRegistered = AutoAnswerGuard.isInCallServiceRegistered(this)
        permissionItems = PermissionManager.inspectPermissions(this)
        simInventory = SimSubscriptionDetector.inspectDualSimSlots(this)
        preferredSim = SimPreferencesStore.getPreferredSim(this)
        autoAnswerSettings = AutoAnswerPreferencesStore.load(this)
        aiAudioCapability = AutoAnswerGuard.inspectAiVoiceCallIntegrationCapability(this)
        callHistoryResult = CallHistoryRepository.loadDeviceCallHistory(this)
    }
}

@Composable
private fun NativeDashboardScreen(
    isDefaultDialer: Boolean,
    inCallServiceRegistered: Boolean,
    inCallServiceBound: Boolean,
    simInventory: DualSimInventoryResult,
    preferredSim: PreferredSimOption,
    autoAnswerSettings: AutoAnswerSettings,
    autoAnswerRuntime: AutoAnswerRuntimeState,
    simTestCountingDown: Boolean,
    simTestRemainingSec: Int,
    simTestStatusBn: String,
    aiAudioCapability: AiCallAudioCapabilityReport,
    autoAnswerTestResults: List<AutoAnswerTestCheck>,
    metrics: DualSimCallMetrics,
    permissionItems: List<AndroidPermissionItem>,
    callHistoryResult: CallHistoryRepository.CallLogResult,
    hasActiveCall: Boolean,
    activeCallSummary: String,
    onSelectPreferredSim: (PreferredSimOption) -> Unit,
    onToggleAutoAnswer: (Boolean) -> Unit,
    onSelectAutoAnswerDelay: (AutoAnswerDelay) -> Unit,
    onToggleAutoAnswerJioOnly: (Boolean) -> Unit,
    onStopAutoAnswerNow: () -> Unit,
    onSimulateFiveSecondAutoAnswer: () -> Unit,
    onRunAutoAnswerTests: () -> Unit,
    onRequestDefaultDialer: () -> Unit,
    onRequestPermissions: () -> Unit,
    onOpenActiveCallScreen: () -> Unit,
    onRefreshAll: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DbtColors.CanvasBlackNavy)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "DBT LAB AI Call Assistant",
                        color = DbtColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dual SIM Management · InCallService · ROLE_DIALER",
                        color = DbtColors.AccentSky,
                        fontSize = 12.sp
                    )
                }
                OutlinedButton(onClick = onRefreshAll) {
                    Text("Refresh", color = DbtColors.AccentSky, fontSize = 12.sp)
                }
            }
        }

        if (hasActiveCall) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = DbtColors.ElevatedNavy,
                    border = BorderStroke(1.dp, DbtColors.AccentBlue)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(activeCallSummary, color = DbtColors.TextPrimary, fontSize = 13.sp)
                        Button(onClick = onOpenActiveCallScreen) {
                            Text("Call Screen", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Dashboard 4-Metric Dual SIM Call Overview
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Dual SIM Call Dashboard",
                    color = DbtColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardStatCard(
                        modifier = Modifier.weight(1f),
                        title = "Jio SIM Incoming Call",
                        value = if (metrics.metricsReady) "${metrics.jioIncomingCalls}" else "Permission Needed"
                    )
                    DashboardStatCard(
                        modifier = Modifier.weight(1f),
                        title = "Other SIM Incoming Call",
                        value = if (metrics.metricsReady) "${metrics.otherSimIncomingCalls}" else "Permission Needed"
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardStatCard(
                        modifier = Modifier.weight(1f),
                        title = "Active Call",
                        value = metrics.activeCallLabel
                    )
                    DashboardStatCard(
                        modifier = Modifier.weight(1f),
                        title = "Missed Call",
                        value = if (metrics.metricsReady) "${metrics.missedCalls}" else "Permission Needed"
                    )
                }
            }
        }

        // Dual SIM Cards: SIM 1 & SIM 2
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Dual SIM Management",
                    color = DbtColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = simInventory.summaryNote,
                    color = DbtColors.TextSecondary,
                    fontSize = 12.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DualSimCard(
                        modifier = Modifier.weight(1f),
                        sim = simInventory.sim1
                    )
                    DualSimCard(
                        modifier = Modifier.weight(1f),
                        sim = simInventory.sim2
                    )
                }
            }
        }

        // Settings: Preferred SIM Selector
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(1.dp, DbtColors.BorderSlate)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Settings · Preferred SIM নির্বাচন",
                        color = DbtColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    PreferredSimOption.entries.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectPreferredSim(option) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = preferredSim == option,
                                onClick = { onSelectPreferredSim(option) }
                            )
                            Text(
                                text = option.labelBn,
                                color = DbtColors.TextPrimary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Settings: Automatic Incoming Call Answer + Stop Button
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(
                    width = 1.dp,
                    color = if (autoAnswerSettings.enabled) DbtColors.AccentBlue else DbtColors.BorderSlate
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Automatic Call Receive (Auto Answer)",
                                color = DbtColors.TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Android Telecom InCallService দিয়ে অনুমোদিতভাবে কল রিসিভ",
                                color = DbtColors.TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = autoAnswerSettings.enabled,
                            onCheckedChange = onToggleAutoAnswer
                        )
                    }

                    // Auto Answer Delay: 3, 5, 10 seconds
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Auto Answer Delay নির্বাচন করুন:",
                            color = DbtColors.TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AutoAnswerDelay.entries.forEach { delayOption ->
                                val selected = autoAnswerSettings.delay == delayOption
                                OutlinedButton(
                                    modifier = Modifier.weight(1f),
                                    onClick = { onSelectAutoAnswerDelay(delayOption) },
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) DbtColors.AccentSky else DbtColors.BorderSlate
                                    ),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (selected) {
                                            DbtColors.AccentBlue.copy(alpha = 0.25f)
                                        } else {
                                            Color.Transparent
                                        }
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = delayOption.labelBn,
                                        color = if (selected) DbtColors.AccentSky else DbtColors.TextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }

                    // Jio SIM Only Option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "শুধু Jio SIM-এর কল Auto Answer করুন",
                                color = DbtColors.TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "চালু থাকলে অন্য SIM-এর কল স্বাভাবিকভাবে রিং হবে।",
                                color = DbtColors.TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = autoAnswerSettings.jioSimOnly,
                            onCheckedChange = onToggleAutoAnswerJioOnly
                        )
                    }

                    // Active Countdown / Emergency Notice
                    if (autoAnswerRuntime.isCountingDown) {
                        Text(
                            text = "চলমান Auto Answer: ${autoAnswerRuntime.remainingSeconds} সেকেন্ড বাকি (${autoAnswerRuntime.statusMessageBn})",
                            color = DbtColors.AccentSky,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else if (autoAnswerRuntime.statusMessageBn.isNotBlank()) {
                        Text(
                            text = autoAnswerRuntime.statusMessageBn,
                            color = DbtColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Text(
                        text = "• Emergency Call (112, 911, 100, 101, 102, 108) কখনোই Auto Answer হবে না।",
                        color = Color(0xFF4ADE80),
                        fontSize = 11.sp
                    )

                    if (simTestCountingDown || simTestStatusBn.isNotBlank()) {
                        Text(
                            text = if (simTestCountingDown) {
                                "কাউন্টডাউন চলছে: $simTestRemainingSec সেকেন্ড — নিচের Stop বাটনে চাপ দিয়ে বাতিল পরীক্ষা করুন।"
                            } else {
                                simTestStatusBn
                            },
                            color = if (simTestCountingDown) DbtColors.AccentSky else Color(0xFF4ADE80),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    OutlinedButton(
                        onClick = onSimulateFiveSecondAutoAnswer,
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, DbtColors.AccentSky),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "${autoAnswerSettings.delay.seconds}s Delay ও ON/OFF লাইভ কাউন্টডাউন পরীক্ষা করুন",
                            color = DbtColors.AccentSky,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (autoAnswerRuntime.isCountingDown || simTestCountingDown || autoAnswerSettings.enabled) {
                        Button(
                            onClick = onStopAutoAnswerNow,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = DbtColors.RejectRed),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Stop Auto Answer (অবিলম্বে বন্ধ করুন)",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Honest AI Voice Audio Integration Check & Real Verification Runner
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(1.dp, DbtColors.BorderSlate)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = aiAudioCapability.statusTitleBn,
                        color = if (aiAudioCapability.canInjectAiVoiceIntoSimCall) {
                            Color(0xFF4ADE80)
                        } else {
                            DbtColors.WarningAmber
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = aiAudioCapability.detailBn,
                        color = DbtColors.TextSecondary,
                        fontSize = 12.sp
                    )

                    Button(
                        onClick = onRunAutoAnswerTests,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = DbtColors.AccentBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Auto Answer সব ফিচার পরীক্ষা করুন",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    autoAnswerTestResults.forEach { check ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DbtColors.ElevatedNavy, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "${if (check.passed) "[PASS]" else "[ACTION NEEDED]"} ${check.nameBn}",
                                color = if (check.passed) Color(0xFF4ADE80) else DbtColors.WarningAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = check.detailBn,
                                color = DbtColors.TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Default Dialer Role & Real InCallService Status
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(1.dp, DbtColors.BorderSlate)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Default Dialer Role ও InCallService অবস্থা",
                        color = DbtColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Default Dialer Role (ROLE_DIALER): ${if (isDefaultDialer) "Active / Held" else "Not Default"}",
                        color = if (isDefaultDialer) Color(0xFF4ADE80) else DbtColors.WarningAmber,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "InCallService Manifest: ${if (inCallServiceRegistered) "Registered (BIND_INCALL_SERVICE)" else "Not Registered"}",
                        color = if (inCallServiceRegistered) Color(0xFF4ADE80) else DbtColors.RejectRed,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "InCallService Binding: ${if (inCallServiceBound) "Bound & Active" else "Unbound (কলের সময় সক্রিয় হয়)"}",
                        color = if (inCallServiceBound) Color(0xFF4ADE80) else DbtColors.TextSecondary,
                        fontSize = 13.sp
                    )
                    if (!isDefaultDialer) {
                        Button(
                            onClick = onRequestDefaultDialer,
                            colors = ButtonDefaults.buttonColors(containerColor = DbtColors.AccentBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Default Phone App সেট করুন", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Android Runtime Permissions
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(1.dp, DbtColors.BorderSlate)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Android Permissions",
                            color = DbtColors.TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        OutlinedButton(onClick = onRequestPermissions) {
                            Text("অনুমতি দিন", color = DbtColors.AccentSky, fontSize = 12.sp)
                        }
                    }
                    permissionItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item.titleBn, color = DbtColors.TextSecondary, fontSize = 12.sp)
                            Text(
                                text = if (item.granted) "Granted" else "Denied",
                                color = if (item.granted) Color(0xFF4ADE80) else DbtColors.WarningAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Honest Android Public API Limits & Zero-OTP Privacy Policy
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DbtColors.SurfaceNavy,
                border = BorderStroke(1.dp, DbtColors.WarningAmber.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Android সীমাবদ্ধতা ও প্রাইভেসি নীতি",
                        color = DbtColors.WarningAmber,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "• SIM কলের অডিওতে সরাসরি AI Voice পাঠানো: Unsupported (Public InCallService API সীমাবদ্ধতা)।",
                        color = DbtColors.TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "• স্ট্যান্ডার্ড SIM কল রেকর্ডিং: Unsupported on Android 9+।",
                        color = DbtColors.TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "• কোনো SIM-এর গোপন তথ্য (IMSI/ICCID) বা SMS/OTP কখনোই সংগ্রহ বা প্রেরণ করা হয় না।",
                        color = Color(0xFF4ADE80),
                        fontSize = 12.sp
                    )
                    if (PublicApiCapabilities.SIM_CARRIER_DETECTION) {
                        Text(
                            text = "• Dual SIM Slot, Jio SIM শনাক্তকরণ ও PhoneAccountHandle ম্যাচিং: Supported।",
                            color = Color(0xFF4ADE80),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Real Device Call History
        item {
            Text(
                text = "Real Device Call History (${callHistoryResult.statusMessage})",
                color = DbtColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (callHistoryResult.entries.isEmpty()) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (callHistoryResult.permissionGranted) {
                        "ডিভাইসের কল লগে কোনো রেকর্ড নেই।"
                    } else {
                        "READ_CALL_LOG অনুমতি দিলে ডিভাইসের প্রকৃত কল হিস্ট্রি দেখা যাবে।"
                    },
                    color = DbtColors.TextSecondary,
                    fontSize = 13.sp
                )
            }
        } else {
            items(callHistoryResult.entries, key = { it.id }) { entry ->
                val formattedDate = SimpleDateFormat("dd MMM · hh:mm a", Locale.getDefault())
                    .format(Date(entry.timestampMillis))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = DbtColors.SurfaceNavy,
                    border = BorderStroke(1.dp, DbtColors.BorderSlate)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = entry.cachedName ?: entry.number,
                            color = DbtColors.TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${entry.number} · ${entry.callTypeLabel} · $formattedDate · ${entry.durationSeconds}s",
                            color = DbtColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DualSimCard(
    modifier: Modifier = Modifier,
    sim: SimSlotInfo
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = DbtColors.SurfaceNavy,
        border = BorderStroke(
            width = 1.dp,
            color = if (sim.isJioSim) DbtColors.AccentBlue else DbtColors.BorderSlate
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "SIM ${sim.slotNumber}",
                color = if (sim.isJioSim) DbtColors.AccentSky else DbtColors.TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = sim.operatorName,
                color = DbtColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Status: ${sim.simStatus}",
                color = if (sim.isActive) Color(0xFF4ADE80) else DbtColors.TextSecondary,
                fontSize = 11.sp
            )
            Text(
                text = "Slot: ${sim.slotNumber} · Number: ${sim.phoneNumber}",
                color = DbtColors.TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun DashboardStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = DbtColors.SurfaceNavy,
        border = BorderStroke(1.dp, DbtColors.BorderSlate)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = title, color = DbtColors.TextSecondary, fontSize = 11.sp)
            Text(
                text = value,
                color = DbtColors.TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
