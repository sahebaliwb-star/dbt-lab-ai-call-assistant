package com.dbtlab.callassistant.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ContactLookupResult(
    val displayName: String?,
    val statusNote: String
)

object ContactsResolver {

    fun lookupCallerName(context: Context, phoneNumber: String): ContactLookupResult {
        val hasContactsPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactsPermission) {
            return ContactLookupResult(
                displayName = null,
                statusNote = "কলারের নাম দেখাতে READ_CONTACTS অনুমতি প্রয়োজন"
            )
        }

        if (phoneNumber.isBlank()) {
            return ContactLookupResult(null, "বৈধ নম্বর নেই")
        }

        val lookupUri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber)
        )

        return runCatching {
            context.contentResolver.query(
                lookupUri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    val name = if (idx >= 0) cursor.getString(idx) else null
                    ContactLookupResult(name, "কন্টাক্টস থেকে শনাক্ত")
                } else {
                    ContactLookupResult(null, "অসংরক্ষিত নম্বর")
                }
            } ?: ContactLookupResult(null, "অসংরক্ষিত নম্বর")
        }.getOrElse {
            ContactLookupResult(null, "কন্টাক্টস অনুসন্ধান ব্যর্থ হয়েছে")
        }
    }
}
