package com.dbtlab.callassistant.telecom

enum class DbtCallState(val labelBn: String) {
    IDLE("কোনো সক্রিয় কল নেই"),
    RINGING("ইনকামিং কল আসছে"),
    DIALING("কল করা হচ্ছে"),
    CONNECTING("সংযুক্ত হচ্ছে"),
    ACTIVE("কল চলছে"),
    HOLDING("হোল্ডে আছে"),
    DISCONNECTED("কল বিচ্ছিন্ন হয়েছে")
}

enum class IncomingSimCategory(val labelBn: String) {
    JIO_SIM("Jio SIM"),
    OTHER_SIM("Other SIM"),
    UNKNOWN_SIM("SIM অজানা")
}

enum class PreferredSimOption(val labelBn: String) {
    ASK_EVERY_TIME("প্রতিবার জিজ্ঞাসা করুন (Auto)"),
    SIM_1("SIM 1 অগ্রাধিকার"),
    SIM_2("SIM 2 অগ্রাধিকার")
}

enum class AutoAnswerDelay(val seconds: Int, val labelBn: String) {
    THREE_SECONDS(3, "৩ সেকেন্ড"),
    FIVE_SECONDS(5, "৫ সেকেন্ড"),
    TEN_SECONDS(10, "১০ সেকেন্ড")
}

data class AutoAnswerSettings(
    val enabled: Boolean = false,
    val delay: AutoAnswerDelay = AutoAnswerDelay.FIVE_SECONDS,
    val jioSimOnly: Boolean = true
)

data class AutoAnswerRuntimeState(
    val isCountingDown: Boolean = false,
    val remainingSeconds: Int = 0,
    val wasCancelledByUser: Boolean = false,
    val autoAnsweredThisCall: Boolean = false,
    val statusMessageBn: String = ""
)

data class SimSlotInfo(
    val slotNumber: Int,
    val subscriptionId: Int?,
    val operatorName: String,
    val simStatus: String,
    val phoneNumber: String,
    val isJioSim: Boolean,
    val isActive: Boolean
)

data class SimCarrierInfo(
    val carrierName: String,
    val simSlotIndex: Int?,
    val subscriptionId: Int?,
    val isJioSim: Boolean,
    val category: IncomingSimCategory,
    val phoneNumber: String,
    val statusNote: String
)

data class DualSimCallMetrics(
    val jioIncomingCalls: Int,
    val otherSimIncomingCalls: Int,
    val activeCallLabel: String,
    val missedCalls: Int,
    val metricsReady: Boolean
)

data class ActiveCallUiState(
    val hasActiveCall: Boolean = false,
    val callerNumber: String = "",
    val callerName: String? = null,
    val contactLookupStatus: String = "",
    val callState: DbtCallState = DbtCallState.IDLE,
    val simInfo: SimCarrierInfo? = null,
    val autoAnswerState: AutoAnswerRuntimeState = AutoAnswerRuntimeState(),
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val callStartTimeMillis: Long = 0L
)

data class CallHistoryEntry(
    val id: Long,
    val number: String,
    val cachedName: String?,
    val callTypeLabel: String,
    val rawCallType: Int,
    val phoneAccountId: String?,
    val timestampMillis: Long,
    val durationSeconds: Long
)

object PublicApiCapabilities {
    const val TELECOM_CALL_SCREEN_CONTROL = true
    const val CONTACTS_AND_CALL_LOG_READ = true
    const val SIM_CARRIER_DETECTION = true
    const val DIRECT_PSTN_UPLINK_AI_INJECTION = false
    const val STANDARD_SIM_DOWNLINK_RECORDING = false

    const val UNSUPPORTED_UPLINK_MESSAGE_BN =
        "Android Public InCallService API ব্যবহার করে সাধারণ SIM কলের অডিওতে সরাসরি AI Voice পাঠানো সম্ভব নয় (Unsupported)।"
}
