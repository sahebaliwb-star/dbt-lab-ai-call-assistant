package com.dbtlab.callassistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dbtlab.callassistant.telecom.ActiveCallUiState
import com.dbtlab.callassistant.telecom.DbtCallState
import com.dbtlab.callassistant.telecom.PublicApiCapabilities
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun IncomingCallScreen(
    uiState: ActiveCallUiState,
    aiAssistantReply: String?,
    aiListening: Boolean,
    aiPanelOpen: Boolean,
    onAnswerCall: () -> Unit,
    onRejectOrEndCall: () -> Unit,
    onStopAutoAnswer: () -> Unit,
    onToggleSpeaker: (Boolean) -> Unit,
    onToggleMute: (Boolean) -> Unit,
    onToggleAiAssistant: () -> Unit,
    onAskAiByVoice: () -> Unit
) {
    var elapsedSeconds by remember { mutableLongStateOf(0L) }

    LaunchedEffect(uiState.callState, uiState.callStartTimeMillis) {
        while (uiState.callState == DbtCallState.ACTIVE && uiState.callStartTimeMillis > 0L) {
            elapsedSeconds = (System.currentTimeMillis() - uiState.callStartTimeMillis) / 1000L
            delay(1000L)
        }
    }

    val durationText = String.format(
        Locale.US,
        "%02d:%02d",
        elapsedSeconds / 60L,
        elapsedSeconds % 60L
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DbtColors.SurfaceNavy, DbtColors.CanvasBlackNavy)
                )
            )
            .padding(horizontal = 24.dp, vertical = 32.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Header: Brand + SIM Carrier + Call State
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "DBT LAB AI Call Assistant",
                    color = DbtColors.AccentSky,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = uiState.simInfo?.statusNote ?: "SIM তথ্য যাচাই হচ্ছে",
                    color = if (uiState.simInfo?.isJioSim == true) DbtColors.AccentSky else DbtColors.TextSecondary,
                    fontSize = 13.sp
                )

                Text(
                    text = if (uiState.callState == DbtCallState.ACTIVE) {
                        "${uiState.callState.labelBn} · $durationText"
                    } else {
                        uiState.callState.labelBn
                    },
                    color = DbtColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Center: Caller Name & Caller Number
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .background(DbtColors.ElevatedNavy, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (uiState.callerName?.firstOrNull() ?: '#').uppercaseChar().toString(),
                        color = DbtColors.AccentSky,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = uiState.callerName ?: "অজানা কলার",
                    color = DbtColors.TextPrimary,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = uiState.callerNumber.ifBlank { "Private Number" },
                    color = DbtColors.TextSecondary,
                    fontSize = 18.sp
                )

                if (uiState.contactLookupStatus.isNotBlank()) {
                    Text(
                        text = uiState.contactLookupStatus,
                        color = DbtColors.TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Auto Answer Countdown Banner & Honest Post-Answer Status
                val autoState = uiState.autoAnswerState
                if (autoState.isCountingDown || autoState.statusMessageBn.isNotBlank()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = if (autoState.isCountingDown) {
                            DbtColors.AccentBlue.copy(alpha = 0.22f)
                        } else {
                            DbtColors.ElevatedNavy
                        },
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (autoState.isCountingDown) DbtColors.AccentSky else DbtColors.BorderSlate
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (autoState.isCountingDown) {
                                Text(
                                    text = "Auto Answer চলছে · ${autoState.remainingSeconds} সেকেন্ড",
                                    color = DbtColors.AccentSky,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (autoState.statusMessageBn.isNotBlank()) {
                                Text(
                                    text = autoState.statusMessageBn,
                                    color = DbtColors.TextPrimary,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }

                            if (autoState.isCountingDown) {
                                Button(
                                    onClick = onStopAutoAnswer,
                                    colors = ButtonDefaults.buttonColors(containerColor = DbtColors.RejectRed),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Stop,
                                        contentDescription = "Stop Auto Answer",
                                        tint = Color.White
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text(
                                        text = "Stop Auto Answer",
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Bengali Female AI Voice Assistant Panel (Local Assistance + Honest Public API Notice)
                if (aiPanelOpen) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        shape = RoundedCornerShape(20.dp),
                        color = DbtColors.ElevatedNavy,
                        border = BorderStroke(1.dp, DbtColors.BorderSlate)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "বাংলা মহিলা AI Voice Assistant (Local Support)",
                                color = DbtColors.AccentSky,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Text(
                                text = aiAssistantReply
                                    ?: "প্রশ্ন করতে নিচের মাইক্রোফোন বাটনে চাপ দিন — AI বাংলায় সহায়তা দেবে।",
                                color = DbtColors.TextPrimary,
                                fontSize = 14.sp
                            )

                            Text(
                                text = PublicApiCapabilities.UNSUPPORTED_UPLINK_MESSAGE_BN,
                                color = DbtColors.WarningAmber,
                                fontSize = 11.sp
                            )

                            Button(
                                onClick = onAskAiByVoice,
                                colors = ButtonDefaults.buttonColors(containerColor = DbtColors.AccentBlue),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Mic, contentDescription = "Voice Input")
                                Spacer(modifier = Modifier.size(8.dp))
                                Text(if (aiListening) "শুনছি..." else "বাংলায় AI-কে বলুন")
                            }
                        }
                    }
                }
            }

            // Bottom Action Zone: AI Assistant, Speaker/Mute, Answer & Reject
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = onToggleAiAssistant,
                        border = BorderStroke(1.dp, DbtColors.AccentSky),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RecordVoiceOver,
                            contentDescription = "AI Assistant",
                            tint = DbtColors.AccentSky
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("AI Assistant", color = DbtColors.TextPrimary, fontSize = 13.sp)
                    }

                    if (uiState.callState == DbtCallState.ACTIVE) {
                        OutlinedButton(
                            onClick = { onToggleSpeaker(!uiState.isSpeakerOn) },
                            border = BorderStroke(1.dp, DbtColors.BorderSlate),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VolumeUp,
                                contentDescription = "Speaker",
                                tint = if (uiState.isSpeakerOn) DbtColors.AccentSky else DbtColors.TextSecondary
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                text = if (uiState.isSpeakerOn) "Speaker On" else "Speaker",
                                color = DbtColors.TextPrimary,
                                fontSize = 13.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { onToggleMute(!uiState.isMuted) },
                            border = BorderStroke(1.dp, DbtColors.BorderSlate),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                text = if (uiState.isMuted) "Unmute" else "Mute",
                                color = DbtColors.TextPrimary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Reject / End Call Button
                    Button(
                        onClick = onRejectOrEndCall,
                        modifier = Modifier.height(60.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DbtColors.RejectRed)
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "Reject Call", tint = Color.White)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = if (uiState.callState == DbtCallState.RINGING) "Reject" else "End Call",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Answer Button (Shown when Incoming Call is Ringing)
                    if (uiState.callState == DbtCallState.RINGING) {
                        Button(
                            onClick = onAnswerCall,
                            modifier = Modifier.height(60.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DbtColors.AnswerGreen)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = "Answer Call", tint = Color.White)
                            Spacer(modifier = Modifier.size(8.dp))
                            Text(
                                text = "Answer",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
