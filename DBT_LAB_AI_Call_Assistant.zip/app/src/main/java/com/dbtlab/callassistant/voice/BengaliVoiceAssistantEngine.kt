package com.dbtlab.callassistant.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class BengaliVoiceAssistantEngine(
    private val context: Context,
    private val backendBaseUrl: String
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech = TextToSpeech(context, this)
    private var speechRecognizer: SpeechRecognizer? = null
    private var isBengaliTtsAvailable = false
    private var activeVoiceName: String = "Checking TTS..."

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val bnLocale = Locale.Builder().setLanguage("bn").setRegion("BD").build()
            val result = tts.setLanguage(bnLocale)
            isBengaliTtsAvailable = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED

            val femaleVoice = tts.voices?.firstOrNull { voice ->
                voice.locale.language == "bn" &&
                    (voice.name.contains("female", ignoreCase = true) ||
                        voice.name.contains("ban", ignoreCase = true))
            } ?: tts.voices?.firstOrNull { it.locale.language == "bn" }

            if (femaleVoice != null) {
                tts.voice = femaleVoice
                activeVoiceName = femaleVoice.name
            } else {
                activeVoiceName = if (isBengaliTtsAvailable) "Default bn-BD" else "Bengali TTS Pack Missing"
            }
        }
    }

    fun getTtsStatusLabel(): String = activeVoiceName

    fun speakBengali(text: String) {
        if (!isBengaliTtsAvailable) return
        tts.setPitch(1.06f)
        tts.setSpeechRate(0.98f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dbt_lab_incoming_assistant")
    }

    fun stopSpeaking() {
        tts.stop()
    }

    fun startListening(
        onTranscript: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val hasMic = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasMic) {
            onError("মাইক্রোফোন অনুমতি (RECORD_AUDIO) প্রদান করা হয়নি।")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("এই ডিভাইসে Speech Recognition সার্ভিস পাওয়া যায়নি।")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val spoken = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        onTranscript(spoken)
                    } else {
                        onError("কোনো কথা শনাক্ত হয়নি।")
                    }
                }
                override fun onError(error: Int) {
                    onError("Speech Recognition ত্রুটি কোড: $error")
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        }
        speechRecognizer?.startListening(intent)
    }

    // Calls your secure server-side Gemini endpoint (API key never embedded in APK)
    suspend fun askAssistantViaServer(userPrompt: String, callerContext: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = URL("$backendBaseUrl/api/chat")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    connectTimeout = 10_000
                    readTimeout = 15_000
                    doOutput = true
                }

                val payload = JSONObject().apply {
                    put("message", "$callerContext\nUser question: $userPrompt")
                    put("preferredLanguage", "bn")
                    put("voicePersona", "Ananya")
                }

                OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }

                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val bodyText = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(bodyText)

                if (conn.responseCode !in 200..299) {
                    throw IllegalStateException(json.optString("error", "Server error ${conn.responseCode}"))
                }

                json.optString("replyText", "উত্তর পাওয়া যায়নি।")
            }
        }

    fun release() {
        tts.stop()
        tts.shutdown()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
