package com.dbtlab.callassistant.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import androidx.core.content.ContextCompat
import com.dbtlab.callassistant.telecom.ActiveCallUiState
import com.dbtlab.callassistant.telecom.CallHistoryEntry
import com.dbtlab.callassistant.telecom.DualSimCallMetrics
import com.dbtlab.callassistant.telecom.DualSimInventoryResult

object CallHistoryRepository {

    data class CallLogResult(
        val entries: List<CallHistoryEntry>,
        val permissionGranted: Boolean,
        val statusMessage: String
    )

    @SuppressLint("MissingPermission")
    fun loadDeviceCallHistory(context: Context, limit: Int = 50): CallLogResult {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED

        if (!granted) {
            return CallLogResult(
                entries = emptyList(),
                permissionGranted = false,
                statusMessage = "কল হিস্ট্রি দেখতে READ_CALL_LOG অনুমতি দিন (কোনো ভুয়া কল লগ দেখানো হয়নি)।"
            )
        }

        val list = mutableListOf<CallHistoryEntry>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.PHONE_ACCOUNT_ID,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION
        )

        runCatching {
            context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndex(CallLog.Calls._ID)
                val numIdx = cursor.getColumnIndex(CallLog.Calls.NUMBER)
                val nameIdx = cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val typeIdx = cursor.getColumnIndex(CallLog.Calls.TYPE)
                val accountIdx = cursor.getColumnIndex(CallLog.Calls.PHONE_ACCOUNT_ID)
                val dateIdx = cursor.getColumnIndex(CallLog.Calls.DATE)
                val durIdx = cursor.getColumnIndex(CallLog.Calls.DURATION)

                while (cursor.moveToNext() && list.size < limit) {
                    val rawType = if (typeIdx >= 0) cursor.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                    val typeLabel = when (rawType) {
                        CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        CallLog.Calls.MISSED_TYPE -> "Missed"
                        CallLog.Calls.REJECTED_TYPE -> "Rejected"
                        else -> "Other"
                    }
                    list.add(
                        CallHistoryEntry(
                            id = if (idIdx >= 0) cursor.getLong(idIdx) else list.size.toLong(),
                            number = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else "অজানা",
                            cachedName = if (nameIdx >= 0) cursor.getString(nameIdx) else null,
                            callTypeLabel = typeLabel,
                            rawCallType = rawType,
                            phoneAccountId = if (accountIdx >= 0) cursor.getString(accountIdx) else null,
                            timestampMillis = if (dateIdx >= 0) cursor.getLong(dateIdx) else 0L,
                            durationSeconds = if (durIdx >= 0) cursor.getLong(durIdx) else 0L
                        )
                    )
                }
            }
        }

        return CallLogResult(
            entries = list,
            permissionGranted = true,
            statusMessage = "${list.size} টি বাস্তব কল রেকর্ড লোড হয়েছে"
        )
    }

    fun computeDualSimMetrics(
        history: CallLogResult,
        simInventory: DualSimInventoryResult,
        activeCall: ActiveCallUiState
    ): DualSimCallMetrics {
        val jioSubId = listOf(simInventory.sim1, simInventory.sim2)
            .firstOrNull { it.isJioSim }
            ?.subscriptionId
            ?.toString()

        val incomingEntries = history.entries.filter { it.rawCallType == CallLog.Calls.INCOMING_TYPE }
        val jioIncoming = if (jioSubId != null) {
            incomingEntries.count { it.phoneAccountId?.contains(jioSubId) == true }
        } else {
            0
        }
        val otherIncoming = (incomingEntries.size - jioIncoming).coerceAtLeast(0)
        val missedCount = history.entries.count { it.rawCallType == CallLog.Calls.MISSED_TYPE }

        val activeLabel = if (activeCall.hasActiveCall) {
            "${activeCall.callState.labelBn} · ${activeCall.simInfo?.carrierName ?: "Active"}"
        } else {
            "None"
        }

        return DualSimCallMetrics(
            jioIncomingCalls = jioIncoming,
            otherSimIncomingCalls = otherIncoming,
            activeCallLabel = activeLabel,
            missedCalls = missedCount,
            metricsReady = history.permissionGranted
        )
    }
}
